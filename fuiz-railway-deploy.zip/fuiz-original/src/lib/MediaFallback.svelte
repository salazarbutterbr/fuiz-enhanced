<script lang="ts">
	import image from '$lib/assets/image.svg';
	import Icon from './Icon.svelte';
</script>

<div
	style:height="100%"
	style:width="100%"
	style:display="flex"
	style:align-items="center"
	style:justify-content="center"
	style:opacity="0.4"
>
	<Icon src={image} alt="fallback" size="50%" />
</div>
