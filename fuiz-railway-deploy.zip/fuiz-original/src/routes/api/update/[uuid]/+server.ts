import { error } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import type { StrictInternalFuiz } from '$lib/storage';
import { update } from '../../oauthUtil';

export const POST: RequestHandler = async ({ request, params: { uuid }, platform, locals }) => {
	const session = await locals.auth();
	const db = platform?.env.DATABASE;
	const storage = platform?.env.BUCKET;
	const userId = session?.user?.id;
	if (!db || !userId || !storage) error(500);

	const data: StrictInternalFuiz = await request.json();

	const { config: content, ...metadata } = data;

	await update(
		{
			id: uuid,
			lastEdited: metadata.lastEdited,
			versionId: metadata.versionId,
			creator: userId
		},
		JSON.stringify(content),
		db,
		storage
	);

	return new Response();
};
