import { i18n } from '$lib/i18n.js';
export const reroute = i18n.reroute();
